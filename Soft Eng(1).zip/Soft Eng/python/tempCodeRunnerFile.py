import hashlib
import mysql.connector
from flask import Flask, request, redirect, url_for, render_template, session, jsonify
from datetime import datetime

app = Flask(__name__, template_folder='../html', static_folder='../html/static')
app.secret_key = 'your_secret_key'

# Database connection setup
db_config = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "ebdb"
}

# db = mysql.connector.connect(**db_config)
# cursor = db.cursor(dictionary=True)

# First page to show
@app.route('/')
def home():
    return render_template('login.html')

# Route for handling user login
@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    hashed_password = hashlib.sha256(password.encode()).hexdigest()

    # Connect to the database
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor(dictionary=True)

    # Query to check user credentials
    query = "SELECT * FROM user WHERE username = %s AND password = %s"
    cursor.execute(query, (username, hashed_password))
    user = cursor.fetchone()

    cursor.close()
    connection.close()

    if user:
        session['username'] = user['username']
        session['role'] = user['role']

        # Redirect based on role
        if user['role'] == 'Admin':
            return redirect(url_for('admin_dashboard'))
        else:
            return redirect(url_for('emp_dashboard'))
    else:
        return render_template('message.html', message="Invalid credentials, please try again.", redirect_url='/')
    
# Route for forgot password
@app.route('/forgot_pass', methods=['GET',' POST'])
def forgot_password():
    return render_template('frgt_pass.html')

@app.route('/forgot_pass_submit', methods=['POST'])
def forgot_pass_submit():
    username = request.form['username']

    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor(dictionary=True)

    query = "SELECT * FROM user WHERE username = %s"
    cursor.execute(query, (username,))
    user = cursor.fetchone()

    cursor.close()
    connection.close()

    if not user:
        return render_template('message.html', message="Username does not exist.", redirect_url='/forgot_pass')

    session['forgot_username'] = username
    return redirect(url_for('security_questions'))

@app.route('/security_questions')
def security_questions():
    return render_template('question.html')

@app.route('/verify_security_questions', methods=['POST'])
def verify_security_questions():
    username = request.form['username']
    answer1 = request.form['answer1'].strip().lower()
    answer2 = request.form['answer2'].strip().lower()

    # Fixed security question answers
    correct_answer1 = "blue"
    correct_answer2 = "iphone"

    if answer1 == correct_answer1 and answer2 == correct_answer2:
        return redirect(url_for('reset_password', username=username))
    else:
        return render_template('message.html', message="Incorrect answers.", redirect_url='/security_questions')
    
@app.route('/reset_password', methods=['GET', 'POST'])
def reset_password():
    if request.method == 'GET':
        return render_template('reset_pass.html', username=request.args.get('username'))
    
    username = request.form['username']
    new_password = request.form['new_password']
    confirm_password = request.form['confirm_password']

    if new_password != confirm_password:
        return render_template('message.html', message="Passwords do not match.", redirect_url='/reset_password')
    
    hashed_password = hashlib.sha256(new_password.encode()).hexdigest()

    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()

    query = "UPDATE user SET password = %s WHERE username = %s"
    cursor.execute(query, (hashed_password, username))
    connection.commit()

    cursor.close()
    connection.close()

    return render_template('message.html', message="Password successfully reset.", redirect_url='/')
    
# Route for admin page
@app.route('/admin')
def admin_dashboard():
    if 'username' in session and session['role'] == 'Admin':
        return render_template('admin.html', username=session['username'])
    return redirect(url_for('home'))

# Route for employee page
@app.route('/employee')
def emp_dashboard():
    if 'username' in session and session['role'] == 'Employee':
        return render_template('emp.html', username=session['username'])
    return redirect(url_for('home'))

# Registration page from Admin panel
@app.route('/register')
def register_page():
    if 'username' in session and session['role'] == 'Admin':
        return render_template('register.html')
    return redirect(url_for('home'))

# Employee registration
@app.route('/register_emp', methods=['GET','POST'])
def register_emp():
    if request.method == 'GET':
        if 'username' in session and session['role'] == 'Admin':
            return render_template('emp_reg.html')
        return redirect(url_for('home'))
        
    try:
        # Get form data
        fname = request.form['fname']
        lname = request.form['lname']
        contacts = request.form['contacts']
        username = request.form['user']
        password = request.form['pass']
        role = request.form['role']

        hashed_password = hashlib.sha256(password.encode()).hexdigest()

        # Connect to the database
        connection = mysql.connector.connect(**db_config)
        cursor = connection.cursor()

        # Insert the data into the user table
        query = """
            INSERT INTO user (firstName, lastName, contacts, username, password, role)
            VALUES (%s, %s, %s, %s, %s, %s)
        """
        values = (fname, lname, contacts, username, hashed_password, role)

        cursor.execute(query, values)
        connection.commit()

        cursor.close()
        connection.close()

        return redirect(url_for('register_emp'))
    
    except Exception as e:
        return f"Error: {e}"
    
# Product registration
@app.route('/register_prod', methods=['GET','POST'])
def register_prod():
    if request.method == 'GET':
        if 'username' in session and session['role'] == 'Admin':
            return render_template('prd_reg.html')
        return redirect(url_for('home'))
        
    try:
        # Get form data
        prod_id = request.form['prod_id']
        prod_name = request.form['prod_name']
        stock = request.form['stock']
        price = request.form['price']
        category = request.form['category']

        # Connect to the database
        connection = mysql.connector.connect(**db_config)
        cursor = connection.cursor()

        # Insert the data into the user table
        query = """
            INSERT INTO prod (prod_id, prod_name, stock, price, category)
            VALUES (%s, %s, %s, %s, %s)
        """
        values = (prod_id, prod_name, stock, price, category)

        cursor.execute(query, values)
        connection.commit()

        cursor.close()
        connection.close()

        return redirect(url_for('register_prod'))
    
    except Exception as e:
        return f"Error: {e}"

@app.route('/inventory')
def inventory_page():
    if 'username' in session:
        try:
            search_query = request.args.get('search', '')

            # Connect to the database
            connection = mysql.connector.connect(**db_config)
            cursor = connection.cursor(dictionary=True)

            if search_query:
                query = "SELECT * FROM prod WHERE prod_name LIKE %s OR category LIKE %s"
                cursor.execute(query, ('%' + search_query + '%', '%' + search_query + '%'))
            else:
                query = "SELECT * FROM prod"
                cursor.execute(query)

            products = cursor.fetchall()

            cursor.close()
            connection.close()

            # Pass products to the template
            return render_template('inventory.html', products=products)

        except Exception as e:
            return f"Error: {e}"
        
    return redirect(url_for('home'))

# Sales page from Admin panel
@app.route('/sales')
def sales_page():
    if 'username' in session and session['role'] == 'Admin':
        return render_template('sales.html')
    return redirect(url_for('home'))

# Customer Page
@app.route('/customer_page', methods=['POST', 'GET'])
def customer_page():
    if request.method == 'POST':
        session['customer_name'] = request.form['customer']
        session['email'] = request.form['email']
        session['contacts'] = request.form['contacts']

        return redirect(url_for('order_page'))
    
    return render_template('customer.html')

# Order Page
@app.route('/order_page', methods=['GET','POST'])
def order_page():
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor(dictionary=True)

    if request.method == 'POST':
        data = request.get_json()  # Fetch JSON data
        print("Recieved order data", data)

        if not data:
            return jsonify({"error": "Invalid data"}), 400  # Error handling

        if 'order_list' not in session:
            session['order_list'] = []

        for item in data:
            prod_id = item['prod_id']
            quantity = int(item['quantity'])

            cursor.execute("SELECT * FROM prod WHERE prod_id = %s", (prod_id,))
            product = cursor.fetchone()

            if product:
                total_price = float(product['price']) * quantity

                # Check if product is already in session
                existing_product = next((p for p in session['order_list'] if p['prod_id'] == prod_id), None)

                if existing_product:
                    existing_product['quantity'] += quantity
                    existing_product['total_price'] += total_price
                else:
                    session['order_list'].append({
                        'prod_id': prod_id,
                        'prod_name': product['prod_name'],
                        'quantity': quantity,
                        'unit_price': float(product['price']),
                        'total_price': total_price
                    })

        session['order_total'] = sum(item['total_price'] for item in session['order_list'])
        cursor.close()
        connection.close()

        return jsonify({"message": "Order received", "redirect": "/checkout_page"})  # Return success response

    cursor.execute("SELECT prod_id, prod_name FROM prod")
    products = cursor.fetchall()
    cursor.close()
    connection.close()
    return render_template('order.html', products=products)

# Getting Product ID by Name
@app.route("/get_product_id_by_name/<product_name>")
def get_product_id_by_name(product_name):
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor(dictionary=True)

    cursor.execute("SELECT prod_id FROM prod WHERE prod_name = %s", (product_name,))
    product = cursor.fetchone()

    cursor.close()
    connection.close()

    if product:
        return jsonify({"found": True, "prod_id": product["prod_id"]})
    else:
        return jsonify({"found": False})

# Checkout Page
@app.route('/checkout_page')
def checkout_page():
    order_list = session.get('order_list', [])
    # print("Checkout order list:", order_list) # Debugging
    total_cash_payment = sum(item['quantity'] * item['unit_price'] for item in order_list)
    return render_template('checkout.html', order_list=order_list, total_cash_payment=total_cash_payment)

# Save all data
@app.route('/submit_checkout', methods=['POST'])
def submit_checkout():
    customer_name = request.form.get('customer_name')
    email = request.form.get('email')
    contacts = request.form.get('contacts')
    total_amount = request.form.get('total_amount')

    # Multiple values (for each product row)
    prod_ids = request.form.getlist('prod_id')
    quantities = request.form.getlist('quantity')
    unit_prices = request.form.getlist('unit_price')

    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()

    try:
        # Step 1: Insert into customer table
        insert_customer = """
            INSERT INTO customer (customer_name, email, contacts)
            VALUES (%s, %s, %s)
        """
        cursor.execute(insert_customer, (customer_name, email, contacts))
        customer_id = cursor.lastrowid

        # Step 2: Insert into orders table
        insert_order = """
            INSERT INTO orders (customer_id, order_date, total_amount)
            VALUES (%s, NOW(), %s)
        """
        cursor.execute(insert_order, (customer_id, total_amount))
        order_id = cursor.lastrowid

        # Step 3: Loop through each product and insert into checkout table
        for i in range(len(prod_ids)):
            prod_id = prod_ids[i]
            quantity = int(quantities[i])
            unit_price = float(unit_prices[i])
            total_price = quantity * unit_price

            # Insert into checkout
            insert_checkout = """
                INSERT INTO checkout (order_id, product_id, quantity, unit_price, total_price)
                VALUES (%s, %s, %s, %s, %s)
            """
            cursor.execute(insert_checkout, (order_id, prod_id, quantity, unit_price, total_price))

            # Step 4: Subtract quantity from inventory (prod table)
            update_stock = """
                UPDATE prod
                SET stock = stock - %s
                WHERE prod_id = %s AND stock >= %s
            """
            cursor.execute(update_stock, (quantity, prod_id, quantity))

        connection.commit()
        return render_template('message.html', message="Checkout successful!", redirect_url='/sales')

    except Exception as e:
        connection.rollback()
        return f"Error during checkout: {e}"

    finally:
        cursor.close()
        connection.close()

# Logout Route
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)